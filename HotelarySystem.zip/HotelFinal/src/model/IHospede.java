package model;

public interface IHospede {

    public long getCpf();
    public String getNome();
    public String getEmail();
    public long getTelefone();
    
}
